<div class="window mt-1">
    <div class=title-bar>
        <div class=title-bar-text> Education.exe</div>
        <div class=title-bar-controls>
            <button aria-label=Help class=notranslate></button>
            <button aria-label=Close class=notranslate></button>
        </div>
    </div>
    <div class=window-body>
        <ul class=tree-view>
            <li>
                <details open>
                    <summary>Advertising</summary>
                    <ul>
                        <li><strong style=color:purple> 🏫 Nevsehir Haci Bektas Veli University </strong>
                        <li>
                            🎓 Graduate : 2014
                        </li>
                    </ul>
                </details>
            </li>
            <li>
                <details open>
                    <summary>Computer Programming</summary>
                    <ul>
                        <li><strong style=color:purple>🏫 Istanbul University </strong>
                        </li>
            </li>
            🎓 Graduate : 2025
            </li>

        </ul>
        </details>
        </li>
        </ul>
    </div>
</div>