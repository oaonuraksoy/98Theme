<div class="window mt-1">
    <div class=title-bar>
        <div class=title-bar-text> Summary.exe</div>
        <div class=title-bar-controls>
            <button aria-label=Help class=notranslate></button>
            <button aria-label=Close class=notranslate></button>
        </div>
    </div>
    <div class=window-body>
        <p>Hello, I'm Onur <strong style=color:purple> AKSOY</strong>, also known as Hackonomist. I was born in 1992 in
            Istanbul.
            I
            studied Advertising at Nevşehir University. After I graduated, I worked for a while
            but the industry didn't fully satisfy me. That's why I decided
            During this process, I decided to improve myself in the field of web and mobile
            development.
            At the moment, I continue to improve myself in the field of web development. </p>
        <p>To contact me, please use one of the following social media accounts
            you can use.</p>
        <div class=row>
            <div class="col col-12 col-md-6">
                <a href=https://www.linkedin.com/in/oaonuraksoy/ target=_blank class=button>LinkedIn</a>
                - <a href=https://x.com/oaonuraksoy target=_blank class=button>Twitter</a> - <a
                    href=https://www.instagram.com/oaonuraksoy/ target=_blank class=button>Instagram</a>
            </div>
        </div>
    </div>
</div>