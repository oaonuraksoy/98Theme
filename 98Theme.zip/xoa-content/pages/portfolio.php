<?php 
require_once ("oa-content/pages-part/header.php");
require_once ("oa-content/pages-part/left-side.php");
?>

<div class="window mt-1">
    <div class="title-bar">
        <div class="title-bar-text"> Portfolio.exe</div>
        <div class="title-bar-controls">

            <button aria-label=Close class=notranslate></button>
        </div>
    </div>
    <div class="window-body">
        <div class="row">
            <div class="col col-6 col-md-3">
                <div class="window">
                    <div class="title-bar">
                        <div class="title-bar-text">Proje Adı</div>
                    </div>
                    <div class="window-body">
                        <img src="https://img.freepik.com/premium-photo/smartphone-balancing-with-pink-background_23-2150271746.jpg"
                            alt="Proje 1" class="profil-image">
                        <p>Bu Projede şunu Yaptık</p>
                        <p>Amacı bu <br> Kullanılan teknolojiler şunlar</p>
                        <p>linki bu -> <a href="#">www.oapp.com</a></p>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>




<?php 
require_once ("oa-content/pages-part/footer.php");
?>