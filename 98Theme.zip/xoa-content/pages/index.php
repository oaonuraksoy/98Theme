<?php 
require_once ("oa-content/pages-part/header.php");
require_once ("oa-content/pages-part/left-side.php");
require_once ("oa-content/pages-part/summary.php");
require_once ("oa-content/pages-part/experience.php");
require_once ("oa-content/pages-part/education.php");
require_once ("oa-content/pages-part/skills.php");
require_once ("oa-content/pages-part/footer.php");
?>