<?php 
require_once ("oa-content/pages-part/header.php");
require_once ("oa-content/pages-part/left-side.php");
?>

<div class="window">
    <div class="title-bar">
        <div class="title-bar-text">Blog-detail.exe</div>
        <div class="title-bar-controls">

            <button aria-label=Close class=notranslate></button>
        </div>
    </div>

    <div class="window-body">
        <img src="https://picsum.photos/200" alt="Proje 1" class="profil-image">
        <p>Blog 1 açıklama</p>
    </div>
</div>



<?php 
require_once ("oa-content/pages-part/footer.php");
?>